<?php
/**
 * RGB E-Bike Deals Finder - Analytics Engine
 * Tracks views, category interactions, and outbound affiliate clicks.
 * Provides a dedicated WP-Admin dashboard for the site owner.
 */

if (!defined('ABSPATH')) {
    exit;
}

define('RGB_DEALS_DB_VERSION', '1.0.0');

/**
 * 1. Self-Healing Database Table Initialization
 */
function rgb_deals_init_analytics_db() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'rgb_deals_events';

    // Only run dbDelta if table doesn't exist or version updated
    if (get_option('rgb_deals_db_ver') !== RGB_DEALS_DB_VERSION || $wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            event_time datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            event_type varchar(32) NOT NULL,
            deal_id varchar(128) DEFAULT NULL,
            deal_title varchar(255) DEFAULT NULL,
            retailer varchar(128) DEFAULT NULL,
            price decimal(10,2) DEFAULT NULL,
            savings decimal(10,2) DEFAULT NULL,
            category varchar(64) DEFAULT NULL,
            filter_name varchar(64) DEFAULT NULL,
            url text DEFAULT NULL,
            visitor_id varchar(64) DEFAULT NULL,
            device varchar(32) DEFAULT NULL,
            referrer text DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY idx_type_time (event_type, event_time),
            KEY idx_deal_time (deal_id, event_time),
            KEY idx_retailer (retailer)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        update_option('rgb_deals_db_ver', RGB_DEALS_DB_VERSION);
    }
}
add_action('init', 'rgb_deals_init_analytics_db');

/**
 * 2. REST API Tracking Endpoint: POST /wp-json/rgb-deals/v1/track
 */
function rgb_deals_register_tracking_routes() {
    register_rest_route('rgb-deals/v1', '/track', array(
        'methods' => 'POST',
        'callback' => 'rgb_deals_handle_track_event',
        'permission_callback' => '__return_true', // Public tracking beacon
    ));
}
add_action('rest_api_init', 'rgb_deals_register_tracking_routes');

function rgb_deals_handle_track_event($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'rgb_deals_events';

    // Parse payload (supports JSON or form-data)
    $params = $request->get_json_params();
    if (empty($params)) {
        $params = $request->get_params();
    }

    $event_type = sanitize_key($params['event_type'] ?? '');
    if (!in_array($event_type, array('view', 'filter', 'click'), true)) {
        return new WP_REST_Response(array('error' => 'Invalid event type'), 400);
    }

    // Ignore obvious search engine crawlers/bots
    $user_agent = sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? '');
    if (preg_match('/(bot|crawl|spider|slurp|facebookexternalhit|bingbot|googlebot|ahrefs)/i', $user_agent)) {
        return new WP_REST_Response(array('status' => 'bot_ignored'), 200);
    }

    // Generate GDPR-compliant anonymized daily visitor hash
    $ip = sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '');
    $visitor_id = hash('sha256', $ip . date('Y-m-d') . $user_agent . wp_salt());

    $deal_id     = sanitize_text_field($params['deal_id'] ?? '');
    $deal_title  = sanitize_text_field($params['deal_title'] ?? '');
    $retailer    = sanitize_text_field($params['retailer'] ?? '');
    $price       = isset($params['price']) ? floatval($params['price']) : null;
    $savings     = isset($params['savings']) ? floatval($params['savings']) : null;
    $category    = sanitize_text_field($params['category'] ?? '');
    $filter_name = sanitize_text_field($params['filter_name'] ?? '');
    $url         = esc_url_raw($params['url'] ?? '');
    $device      = sanitize_text_field($params['device'] ?? 'Desktop');
    $referrer    = esc_url_raw($params['referrer'] ?? '');

    $wpdb->insert(
        $table_name,
        array(
            'event_time'   => current_time('mysql'),
            'event_type'   => $event_type,
            'deal_id'      => $deal_id ?: null,
            'deal_title'   => $deal_title ?: null,
            'retailer'     => $retailer ?: null,
            'price'        => $price,
            'savings'      => $savings,
            'category'     => $category ?: null,
            'filter_name'  => $filter_name ?: null,
            'url'          => $url ?: null,
            'visitor_id'   => $visitor_id,
            'device'       => $device,
            'referrer'     => $referrer ?: null
        ),
        array('%s', '%s', '%s', '%s', '%s', '%f', '%f', '%s', '%s', '%s', '%s', '%s', '%s')
    );

    return new WP_REST_Response(array('success' => true), 200);
}

/**
 * 3. Register WP-Admin Menu for Deals Analytics
 */
function rgb_deals_register_admin_menu() {
    add_menu_page(
        'E-Bike Deals Analytics',
        'Deals Analytics',
        'manage_options',
        'rgb-deals-analytics',
        'rgb_render_deals_analytics_page',
        'dashicons-chart-area',
        26
    );
}
add_action('admin_menu', 'rgb_deals_register_admin_menu');

/**
 * 4. Render Deals Analytics Dashboard in WP-Admin
 */
function rgb_render_deals_analytics_page() {
    if (!is_admin() || !current_user_can('manage_options')) {
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'rgb_deals_events';

    // Handle Purge Action if requested
    if (isset($_POST['rgb_purge_nonce']) && wp_verify_nonce($_POST['rgb_purge_nonce'], 'rgb_purge_action')) {
        $days = intval($_POST['purge_days'] ?? 90);
        $wpdb->query($wpdb->prepare("DELETE FROM $table_name WHERE event_time < DATE_SUB(NOW(), INTERVAL %d DAY)", $days));
        echo '<div class="notice notice-success is-dismissible"><p>Cleaned up events older than ' . esc_html($days) . ' days.</p></div>';
    }

    // Determine Date Filter
    $period = sanitize_key($_GET['period'] ?? 'today');
    switch ($period) {
        case 'yesterday':
            $where_date = "DATE(event_time) = SUBDATE(CURDATE(), 1)";
            $period_label = "Yesterday";
            break;
        case '7days':
            $where_date = "event_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
            $period_label = "Last 7 Days";
            break;
        case '30days':
            $where_date = "event_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
            $period_label = "Last 30 Days";
            break;
        case 'all':
            $where_date = "1=1";
            $period_label = "All Time";
            break;
        case 'today':
        default:
            $where_date = "DATE(event_time) = CURDATE()";
            $period_label = "Today (" . date_i18n('j M Y') . ")";
            break;
    }

    // Query 1: Total Views and Unique Visitors
    $views_stats = $wpdb->get_row("
        SELECT 
            COUNT(*) as total_views,
            COUNT(DISTINCT visitor_id) as unique_visitors
        FROM $table_name 
        WHERE event_type = 'view' AND $where_date
    ");

    // Query 2: Outbound Clicks and Clickers
    $clicks_stats = $wpdb->get_row("
        SELECT 
            COUNT(*) as total_clicks,
            COUNT(DISTINCT visitor_id) as unique_clickers,
            SUM(price) as total_value,
            SUM(savings) as total_savings
        FROM $table_name 
        WHERE event_type = 'click' AND $where_date
    ");

    // Query 3: Section / Filter Interactions
    $filter_stats = $wpdb->get_row("
        SELECT COUNT(*) as total_filters
        FROM $table_name 
        WHERE event_type = 'filter' AND $where_date
    ");

    $total_views   = intval($views_stats->total_views ?? 0);
    $unique_users  = intval($views_stats->unique_visitors ?? 0);
    $total_clicks  = intval($clicks_stats->total_clicks ?? 0);
    $total_filters = intval($filter_stats->total_filters ?? 0);
    $ctr = $total_views > 0 ? round(($total_clicks / $total_views) * 100, 1) : 0;

    // Query 4: Top Clicked Bikes
    $top_bikes = $wpdb->get_results("
        SELECT 
            deal_id,
            deal_title,
            retailer,
            price,
            savings,
            category,
            url,
            COUNT(*) as click_count,
            MAX(event_time) as last_clicked
        FROM $table_name 
        WHERE event_type = 'click' AND $where_date
        GROUP BY deal_id, deal_title, retailer, price, savings, category, url
        ORDER BY click_count DESC, last_clicked DESC
        LIMIT 15
    ");

    // Query 5: Popular Categories & Filter Tabs Clicked
    $top_filters = $wpdb->get_results("
        SELECT 
            filter_name,
            COUNT(*) as count
        FROM $table_name 
        WHERE event_type = 'filter' AND filter_name != '' AND $where_date
        GROUP BY filter_name
        ORDER BY count DESC
        LIMIT 10
    ");

    // Query 6: Clicks by Retailer
    $top_retailers = $wpdb->get_results("
        SELECT 
            retailer,
            COUNT(*) as count
        FROM $table_name 
        WHERE event_type = 'click' AND retailer != '' AND $where_date
        GROUP BY retailer
        ORDER BY count DESC
        LIMIT 8
    ");

    // Query 7: Recent Live Click Activity (Last 25 outbound clicks)
    $recent_clicks = $wpdb->get_results("
        SELECT 
            event_time,
            deal_title,
            retailer,
            price,
            savings,
            device,
            url
        FROM $table_name 
        WHERE event_type = 'click'
        ORDER BY event_time DESC
        LIMIT 25
    ");
    ?>
    <div class="wrap rgb-analytics-wrap" style="max-width: 1200px; margin-top: 20px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
        <!-- Header -->
        <div style="display: flex; justify-content: space-between; align-items: center; background: #1e3a2f; color: #ffffff; padding: 20px 24px; border-radius: 12px; margin-bottom: 24px; box-shadow: 0 4px 14px rgba(0,0,0,0.1);">
            <div>
                <h1 style="color: #ffffff; margin: 0; font-size: 1.6rem; font-weight: 800; display: flex; align-items: center; gap: 10px;">
                    ⚡ Reight Good Bikes <span style="font-size: 0.95rem; font-weight: 500; background: #10b981; color: #ffffff; padding: 3px 10px; border-radius: 20px;">Deals Analytics</span>
                </h1>
                <p style="margin: 6px 0 0 0; color: #a7f3d0; font-size: 0.92rem;">
                    Real-time audience usage, filter interactions, and outgoing affiliate partner clicks.
                </p>
            </div>
            <div>
                <a href="<?php echo esc_url(add_query_arg('period', $period)); ?>" class="button" style="background: #ffffff; color: #1e3a2f; font-weight: 700; border: none; padding: 6px 16px; border-radius: 6px;">
                    🔄 Refresh Data
                </a>
            </div>
        </div>

        <!-- Date Range Filter Tabs -->
        <div style="margin-bottom: 24px; display: flex; gap: 8px; flex-wrap: wrap;">
            <?php
            $periods = array(
                'today'     => '📅 Today',
                'yesterday' => '⏮️ Yesterday',
                '7days'     => '📊 Last 7 Days',
                '30days'    => '📈 Last 30 Days',
                'all'       => '🌐 All Time'
            );
            foreach ($periods as $key => $label):
                $active = ($period === $key);
                $url = add_query_arg('period', $key);
            ?>
                <a href="<?php echo esc_url($url); ?>" 
                   style="text-decoration: none; padding: 8px 16px; border-radius: 20px; font-weight: 700; font-size: 0.88rem; transition: all 0.15s ease; <?php echo $active ? 'background: #1e3a2f; color: #ffffff; box-shadow: 0 2px 6px rgba(30,58,47,0.3);' : 'background: #ffffff; color: #475569; border: 1px solid #cbd5e1;'; ?>">
                    <?php echo esc_html($label); ?>
                </a>
            <?php endforeach; ?>
        </div>

        <!-- KPI Cards Grid -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; margin-bottom: 28px;">
            <!-- Card 1: Views -->
            <div style="background: #ffffff; padding: 20px; border-radius: 10px; border: 1px solid #e2e8f0; border-left: 5px solid #0284c7; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                <div style="color: #64748b; font-size: 0.82rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">Deals Hub Views</div>
                <div style="font-size: 2rem; font-weight: 800; color: #0f172a; margin: 6px 0;"><?php echo number_format($total_views); ?></div>
                <div style="color: #0284c7; font-size: 0.82rem; font-weight: 600;">👥 <?php echo number_format($unique_users); ?> unique visitors</div>
            </div>

            <!-- Card 2: Outbound Clicks -->
            <div style="background: #ffffff; padding: 20px; border-radius: 10px; border: 1px solid #e2e8f0; border-left: 5px solid #10b981; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                <div style="color: #64748b; font-size: 0.82rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">Outbound Bike Clicks</div>
                <div style="font-size: 2rem; font-weight: 800; color: #0f172a; margin: 6px 0;"><?php echo number_format($total_clicks); ?></div>
                <div style="color: #10b981; font-size: 0.82rem; font-weight: 600;">🎯 Users visiting bike shops</div>
            </div>

            <!-- Card 3: CTR -->
            <div style="background: #ffffff; padding: 20px; border-radius: 10px; border: 1px solid #e2e8f0; border-left: 5px solid #f59e0b; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                <div style="color: #64748b; font-size: 0.82rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">Click-Through Rate (CTR)</div>
                <div style="font-size: 2rem; font-weight: 800; color: #0f172a; margin: 6px 0;"><?php echo esc_html($ctr); ?>%</div>
                <div style="color: #f59e0b; font-size: 0.82rem; font-weight: 600;">⚡ Engagement efficiency</div>
            </div>

            <!-- Card 4: Filter Interactions -->
            <div style="background: #ffffff; padding: 20px; border-radius: 10px; border: 1px solid #e2e8f0; border-left: 5px solid #8b5cf6; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                <div style="color: #64748b; font-size: 0.82rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">Category & Filter Clicks</div>
                <div style="font-size: 2rem; font-weight: 800; color: #0f172a; margin: 6px 0;"><?php echo number_format($total_filters); ?></div>
                <div style="color: #8b5cf6; font-size: 0.82rem; font-weight: 600;">🔍 Section navigation clicks</div>
            </div>
        </div>

        <!-- 2 Column Layout: Top Clicked Bikes & Category Popularity -->
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px; margin-bottom: 28px;">
            <!-- Column 1: Top Clicked Bikes -->
            <div style="background: #ffffff; border-radius: 10px; border: 1px solid #e2e8f0; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                <h2 style="font-size: 1.15rem; font-weight: 800; color: #1e293b; margin: 0 0 16px 0; display: flex; align-items: center; justify-content: space-between;">
                    <span>🏆 Top Clicked Bikes (<?php echo esc_html($period_label); ?>)</span>
                    <span style="font-size: 0.82rem; font-weight: 600; color: #64748b;">Ranked by outgoing clicks</span>
                </h2>

                <?php if (empty($top_bikes)): ?>
                    <div style="text-align: center; padding: 32px 16px; color: #94a3b8; font-size: 0.95rem;">
                        No outbound clicks recorded for this period yet. As visitors browse and click "View Deal", the most popular bikes will rank here.
                    </div>
                <?php else: ?>
                    <table class="wp-list-table widefat striped" style="border: none; box-shadow: none;">
                        <thead>
                            <tr style="background: #f8fafc;">
                                <th style="font-weight: 700; color: #475569; width: 40px;">#</th>
                                <th style="font-weight: 700; color: #475569;">E-Bike Model</th>
                                <th style="font-weight: 700; color: #475569;">Retailer</th>
                                <th style="font-weight: 700; color: #475569;">Price / Savings</th>
                                <th style="font-weight: 700; color: #475569; text-align: center;">Clicks</th>
                                <th style="font-weight: 700; color: #475569; width: 60px;">Link</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $rank = 1;
                            foreach ($top_bikes as $bike): 
                            ?>
                                <tr>
                                    <td style="font-weight: 800; color: <?php echo $rank <= 3 ? '#eab308' : '#64748b'; ?>;">
                                        <?php echo $rank <= 3 ? ($rank === 1 ? '🥇' : ($rank === 2 ? '🥈' : '🥉')) : '#' . $rank; ?>
                                    </td>
                                    <td>
                                        <div style="font-weight: 700; color: #0f172a; font-size: 0.92rem;"><?php echo esc_html($bike->deal_title); ?></div>
                                        <?php if (!empty($bike->category)): ?>
                                            <span style="background: #f1f5f9; color: #475569; font-size: 0.72rem; padding: 2px 6px; border-radius: 4px; font-weight: 600; text-transform: uppercase;">
                                                <?php echo esc_html($bike->category); ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="color: #334155; font-weight: 600; font-size: 0.88rem;">
                                        <?php echo esc_html($bike->retailer); ?>
                                    </td>
                                    <td>
                                        <span style="font-weight: 700; color: #15803d; font-size: 0.92rem;">£<?php echo number_format($bike->price, 2); ?></span>
                                        <?php if ($bike->savings > 0): ?>
                                            <div style="font-size: 0.76rem; color: #b91c1c; font-weight: 600;">Save £<?php echo number_format($bike->savings, 0); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td style="text-align: center;">
                                        <span style="background: #ecfdf5; color: #047857; font-weight: 800; font-size: 0.92rem; padding: 4px 10px; border-radius: 12px;">
                                            <?php echo number_format($bike->click_count); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if (!empty($bike->url)): ?>
                                            <a href="<?php echo esc_url($bike->url); ?>" target="_blank" rel="noopener" style="text-decoration: none; font-size: 1.1rem;" title="View Deal Page">
                                                🔗
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php 
                            $rank++;
                            endforeach; 
                            ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- Column 2: Category & Retailer Popularity -->
            <div style="display: flex; flex-direction: column; gap: 20px;">
                <!-- Filter Tabs Usage -->
                <div style="background: #ffffff; border-radius: 10px; border: 1px solid #e2e8f0; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                    <h3 style="font-size: 1.05rem; font-weight: 800; color: #1e293b; margin: 0 0 14px 0;">
                        🏷️ Filter & Category Clicks
                    </h3>
                    <?php if (empty($top_filters)): ?>
                        <div style="color: #94a3b8; font-size: 0.88rem; padding: 12px 0;">No category clicks recorded yet.</div>
                    <?php else: ?>
                        <div style="display: flex; flex-direction: column; gap: 10px;">
                            <?php 
                            $max_filter_count = max(array_map(function($f) { return intval($f->count); }, $top_filters));
                            foreach ($top_filters as $f): 
                                $pct = $max_filter_count > 0 ? round(($f->count / $max_filter_count) * 100) : 0;
                            ?>
                                <div>
                                    <div style="display: flex; justify-content: space-between; font-size: 0.84rem; font-weight: 600; color: #334155; margin-bottom: 4px;">
                                        <span><?php echo esc_html($f->filter_name); ?></span>
                                        <span style="color: #64748b;"><?php echo number_format($f->count); ?> clicks</span>
                                    </div>
                                    <div style="background: #f1f5f9; height: 8px; border-radius: 4px; overflow: hidden;">
                                        <div style="background: #8b5cf6; width: <?php echo esc_attr($pct); ?>%; height: 100%; border-radius: 4px;"></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Retailer Clicks -->
                <div style="background: #ffffff; border-radius: 10px; border: 1px solid #e2e8f0; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                    <h3 style="font-size: 1.05rem; font-weight: 800; color: #1e293b; margin: 0 0 14px 0;">
                        🏪 Outbound Clicks by Retailer
                    </h3>
                    <?php if (empty($top_retailers)): ?>
                        <div style="color: #94a3b8; font-size: 0.88rem; padding: 12px 0;">No retailer clicks recorded yet.</div>
                    <?php else: ?>
                        <div style="display: flex; flex-direction: column; gap: 8px;">
                            <?php foreach ($top_retailers as $ret): ?>
                                <div style="display: flex; justify-content: space-between; align-items: center; padding: 6px 10px; background: #f8fafc; border-radius: 6px; font-size: 0.86rem;">
                                    <span style="font-weight: 700; color: #1e293b;"><?php echo esc_html($ret->retailer); ?></span>
                                    <span style="background: #dbeafe; color: #1e40af; font-weight: 800; padding: 2px 8px; border-radius: 10px; font-size: 0.8rem;">
                                        <?php echo number_format($ret->count); ?>
                                    </span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Live Real-Time Outbound Click Feed -->
        <div style="background: #ffffff; border-radius: 10px; border: 1px solid #e2e8f0; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); margin-bottom: 28px;">
            <h2 style="font-size: 1.15rem; font-weight: 800; color: #1e293b; margin: 0 0 16px 0; display: flex; align-items: center; justify-content: space-between;">
                <span>⚡ Live Outbound Clicks Feed (Latest 25)</span>
                <span style="font-size: 0.82rem; font-weight: 600; color: #10b981;">● Real-time stream</span>
            </h2>

            <?php if (empty($recent_clicks)): ?>
                <div style="text-align: center; padding: 32px 16px; color: #94a3b8; font-size: 0.95rem;">
                    No recent outbound clicks yet. When someone on your site clicks a deal button to go to a bike shop, it will appear here in real-time.
                </div>
            <?php else: ?>
                <table class="wp-list-table widefat striped" style="border: none; box-shadow: none;">
                    <thead>
                        <tr style="background: #f8fafc;">
                            <th style="font-weight: 700; color: #475569; width: 140px;">Time</th>
                            <th style="font-weight: 700; color: #475569;">E-Bike Clicked</th>
                            <th style="font-weight: 700; color: #475569;">Retailer</th>
                            <th style="font-weight: 700; color: #475569;">Price</th>
                            <th style="font-weight: 700; color: #475569; width: 90px;">Device</th>
                            <th style="font-weight: 700; color: #475569; width: 60px;">Link</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_clicks as $rc): ?>
                            <tr>
                                <td style="color: #64748b; font-size: 0.84rem; font-weight: 600;">
                                    <?php echo esc_html(human_time_diff(strtotime($rc->event_time), current_time('timestamp')) . ' ago'); ?>
                                </td>
                                <td style="font-weight: 700; color: #0f172a; font-size: 0.9rem;">
                                    <?php echo esc_html($rc->deal_title); ?>
                                </td>
                                <td style="color: #334155; font-weight: 600; font-size: 0.86rem;">
                                    <?php echo esc_html($rc->retailer); ?>
                                </td>
                                <td style="font-weight: 700; color: #15803d; font-size: 0.88rem;">
                                    £<?php echo number_format($rc->price, 2); ?>
                                </td>
                                <td>
                                    <span style="font-size: 0.8rem; background: #f1f5f9; padding: 2px 6px; border-radius: 4px; font-weight: 600; color: #475569;">
                                        <?php echo $rc->device === 'Mobile' ? '📱 Mobile' : '💻 Desktop'; ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if (!empty($rc->url)): ?>
                                        <a href="<?php echo esc_url($rc->url); ?>" target="_blank" rel="noopener" style="text-decoration: none; font-size: 1.1rem;" title="View Deal Link">
                                            🔗
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Maintenance / Purge Card -->
        <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px 20px; display: flex; justify-content: space-between; align-items: center;">
            <div>
                <span style="font-weight: 700; color: #334155; font-size: 0.88rem;">Database Maintenance</span>
                <span style="color: #64748b; font-size: 0.84rem; margin-left: 8px;">Keep your database lean by automatically pruning old event logs.</span>
            </div>
            <form method="post" style="margin: 0;" onsubmit="return confirm('Prune events older than 90 days?');">
                <?php wp_nonce_field('rgb_purge_action', 'rgb_purge_nonce'); ?>
                <input type="hidden" name="purge_days" value="90">
                <button type="submit" class="button button-secondary" style="font-size: 0.84rem;">
                    🧹 Clean Logs Older Than 90 Days
                </button>
            </form>
        </div>
    </div>
    <?php
}
